<style>
    * {
        font-family: sans-serif;
    }

    span {
        display: inline-block;
        width: 40px;
        height: 40px;
        /*position: absolute;*/
    }
</style>

<?php
    include("rainbowIterator.php");

    $red = 0;
    $green = 0;
    $blue = 0;

    echo "<h1>" ."Using Iterator: " .$iterator ."</h1>";
    
    do {
        $iterator++;
        
        for($red = 0; $red < 256; $red += $iterator) {
            for($green = 0; $green < 256; $green += $iterator) {
                for($blue = 0; $blue < 256; $blue += $iterator) {
                    $hexRed = sprintf("%02x", $red);
                    $hexGreen = sprintf("%02x", $green);
                    $hexBlue = sprintf("%02x", $blue);
                    
                    echo "<span style=\"background-color: rgb(" .$red ."," .$green ."," .$blue .");\"
                                title=\"" ."#" .$hexRed .$hexGreen .$hexBlue ."\">
                        </span>";
                }
            }
        }
    } while($iterator < 256);
?>