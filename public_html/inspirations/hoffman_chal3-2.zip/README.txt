//////////////////////////////////////////////////////////////////
//								//
//	J. Hoffman						//
//								//
//	PROJECT:	Color Iterator. 			//
//	CREATED: 	01/29/18				//
//								//
//////////////////////////////////////////////////////////////////

	01. ABOUT
	02. VIEWING

//ABOUT://========================================================

	What had initially started as a several-month study on 
	finite state automata in my free time outside of school, 
	later accumulated into a simple game engine programmed 
	utilizing only Javas wonderful but slightly cumbersome 
	standard library.

//VIEWING://======================================================
	
	1. you'll need a Cloud9 account
	2. extract the .zip to a desired folder
	3. import the project into Cloud9
	4. hit "Run" located at the top of the IDE
	5. left of that run button, click "preview" -> 
	   "running application"
	6. An "Index Of/" page should show up, click the file named
	   "scr_chal3-2_rainbow.php"
	
	7. to change the iteration value locate the file named
	   "rainbowIterator.php" and change the value from 32 to
	   your desired value

//EOF//===========================================================