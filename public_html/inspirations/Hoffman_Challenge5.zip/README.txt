//////////////////////////////////////////////////////////////////
//								//
//	J. Hoffman						//
//								//
//	PROJECT:	SNEK. 					//
//	CREATED: 	09/22/17				//
//								//
//////////////////////////////////////////////////////////////////

	01. ABOUT
	02. VIEWING

//ABOUT://========================================================

	The inevitable result of approximately six hours of binge 
	programming, the aptly named "SNEK" game quickly gained 
	notoriety amongst both students and staff alike for its 
	simple yet surprisingly difficult premise.

//VIEWING://======================================================
	
	1. double click the .exe
	2. you may need to explicitly tell your computer how to 
	   run the file "right click" -> "open with"...

//EOF//===========================================================