//////////////////////////////////////////////////////////////////
//								//
//	J. Hoffman						//
//								//
//	PROJECT:	Beyond Oasis				//
//	CREATED: 	12/07/17				//
//								//
//////////////////////////////////////////////////////////////////

	01. ABOUT
	02. VIEWING

//ABOUT://========================================================

	The final version you see here is the result of two 
	assignments from differing courses of loosely connected 
	subject matter. The first being a web design course, 
	whereas the second, instead pertained exclusively to Linux 
	server administration. The already developed fictional 
	band page was subsequently used to learn about site 
	hosting, and for a brief period, even occupied a live 
	space on the internet.

//VIEWING://======================================================
	
	1. open the "public_html" folder
	2. double click the "index.html" file
	3. you may need to explicitly tell your computer how to 
	   run the file "right click" -> "open with"...
	4. select a browser of your choice if #3 is true

//EOF//===========================================================